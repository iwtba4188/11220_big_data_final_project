|編號|照片|真實值|預測值|說明|
|-|-|-|-|-|
|A|![alt text](true_ai-midjourney_pred_real_ecwgqhupgef.jpg)|AI|Real|原始資料庫圖片|
|A-1|![alt text](AAA.jpg)|AI|Real|A 彩度降低後|
|B|![alt text](true_ai-midjourney_pred_real_ddwwwnkhzmg.jpg)|AI|Real|原始資料庫圖片|
|B-1|![alt text](BBB.jpg)|AI|Real|B 彩度降低後|
|B-2|![alt text](CCC.jpg)|AI|Real|B 彩度提高後|
|B-3|![alt text](DDD.jpg)|AI|AI|B-2 背景增加彩度高筆畫後|
|B-4|![alt text](EEE.jpg)|AI|Real|B-2 背景加入真實圖片|
|C|![alt text](S__101621762.jpg)|Real|Real|我們自行拍攝的圖片|
|C-1|![alt text](S__101621763.jpg)|Real|AI|C 彩度提高後|